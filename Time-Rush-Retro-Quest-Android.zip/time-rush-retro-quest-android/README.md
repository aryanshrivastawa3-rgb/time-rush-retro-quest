# Time Rush: Retro Quest — Android wrapper

This project wraps the existing HTML/JavaScript game in a fullscreen Android WebView. The game files are bundled locally and the app does not request internet or location permissions.

## Project details
- Display name: Time Rush: Retro Quest
- Application ID: `com.timerush.retroquest` (choose your final ID before first publishing; changing it later creates a different app)
- Target SDK: 36 (Android 16 requirement for new Google Play apps from Aug 31, 2026)
- Minimum SDK: 23
- Orientation: landscape
- Build outputs: debug APK and release AAB

## Phone-only cloud build
1. On your phone, open GitHub in Chrome and create a **private** repository named `time-rush-retro-quest`.
2. Upload all files/folders from this project ZIP, keeping the folder structure intact. The `.github/workflows/android-build.yml` file must be included.
3. Open the repository's **Actions** tab and enable workflows if asked. Select **Build Time Rush Android** and tap **Run workflow**.
4. When the workflow finishes, open the run and download the `time-rush-android-build` artifact. It contains a debug APK and an AAB. Without signing secrets, the AAB is **unsigned and not uploadable to Play Console**; the APK is for local testing only.

## Configure signing for a Play-ready AAB
A release AAB must be signed. Create a private release keystore with a trusted Android signing workflow/tool, then add these repository Actions secrets (Settings → Secrets and variables → Actions):
- `ANDROID_KEYSTORE_BASE64`: the keystore file encoded as Base64
- `ANDROID_KEYSTORE_PASSWORD`: keystore password
- `ANDROID_KEY_ALIAS`: key alias
- `ANDROID_KEY_PASSWORD`: key password

Never commit the keystore or passwords to the repository, and keep a secure offline backup. If you lose the key, future update signing can be difficult. Use Google Play App Signing when setting up the app in Play Console.

Once secrets are configured, run the workflow again; its AAB will be signed. The workflow artifact expires after 14 days, so download and back up your release outputs promptly.

## Before publishing
- Install the debug APK on a real phone and test movement, jump, all 13 levels, pause/resume behavior, orientation and screen scaling.
- Check that the title and icon look correct.
- Prepare store listing, screenshots, privacy policy/data safety answers and content rating honestly.
- Create the Play Console developer account and complete its verification/testing requirements.
- Check the latest Play Console policy requirements before release.

This is a starter Android wrapper project, not a claim that an AAB has already been built or accepted by Google Play. A successful cloud build and real-device testing are still required.
